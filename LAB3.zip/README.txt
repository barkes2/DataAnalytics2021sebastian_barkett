Folders are organized based on Q1a, Q1b, etc.
All figures are exported as .pngs, descriptions are .txt files. All located in respective folders.
Q2 folder is not subdivided because there wasn't a ton of content

All code is in LAB3 R file and included in the code is the output from the Chi-sq tests to be compared with the 
accompanying .txt file with explanations.